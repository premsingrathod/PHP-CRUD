<?php 

if(isset($_GET["id"])) {
  $id = $_GET["id"];

  $servername="localhost";
  $username="root";
  $password="";
  $dbname="crud";

$conn = new mysqli($server_name, $user_name, $password, $database);

  $sql = "DELETE FROM clients WHERE id = $id";
  $conn->query($sql);

  header("location: ./index.php");
  exit;
}