<?php 
$servername="localhost";
$username="root";
$password="";
$dbname="crud";
$conn=new mysqli($servername, $username, $password, $dbname);
$name=$email=$phone=$address=$errorMessage=$successMessage='';
if($_SERVER["REQUEST_METHOD"]=='POST')
{
    $name=$_POST["name"];
    $email=$_POST["email"];
    $phone=$_POST["phone"];
    $address=$_POST["address"];
    do{
        if(empty($name) || empty($email) || empty($phone) || empty($address))
        {
            $errorMessage='All the field are required';
            break;
        }
        $sql="INSERT INTO clients(name, email, phone, address)"."values('$name', '$email', '$phone', '$address')";
        $result=$conn->query($sql);
        if(!$result)
        {
            $errorMessage="Invalid query: " .$conn->error;
            break;
        }
        $name=$email=$phone=$address='';
        $successMessage="client addres correctly";
        header("location:./index.php");
    }while(false);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>CRUDS</title>
</head>
<body>
    <div class='container my-5'>
        <h2>New Client </h2>
        <?php 
        if(!empty($errorMessage))
        {
            echo "<div class='alert alert-waring alert-dismissible fade sho' role='alert'>
            <strong>$errorMessage</strong>
            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='close'></button>

              </div>";
        }
        
        ?>
        <form method="POST">
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Name</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="name" value="<?php echo $name;?>">
                </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-3 col-form-label">Email:</label>
                    <div class="col-sm-6">
                        <input type="email" name="email" class="form-control" value="<?php echo $email;?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-3 col-form-label">phone:</label>
                    <div class="col-sm-6">
                        <input type="email" name="phone" class="form-control" value="<?php echo $phone;?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-3 col-form-label">Address:</label>
                    <div class="col-sm-6">
                        <input type="email" name="address" class="form-control" value="<?php echo $address;?>">
                    </div>
                </div>
                <?php 
      
                if(!empty($successMessage)) {
                echo "<div class='row mb-3'>
                <div class='offset-sm-3 col-sm-6'>
                    <div class='alert alert-success alert-dismissible fade show' role='alert'>
                    <strong>$successMessage</strong>
                    <button class='btn-close' type='button' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>
                </div>
                </div>";
                }
                
                ?>
                <div class='row mb-3'>
                <div class='offset-sm-3 col-sm-3 d-grid'>
                <button class='btn btn-primary' type='submit'>Submit</button>
                </div>
                <div class='col-sm-3 d-grid'>
                <a href="./index.php" class='btn btn-outline-primary' role='button'>Cancel</a>
                </div>
            </div>
        </form>
    </div>
</body>
</html>